<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv-SE" sourcelanguage="en">
  <context>
    <name>Page</name>
    <message>
      <source>Text for translation</source>
      <comment>commenting</comment>
      <translation type="unfinished">Text for translation</translation>
    </message>
    <message>
      <source>This is some text.</source>
      <extracomment>some text</extracomment>
      <translation type="unfinished">This is some text.</translation>
    </message>
  </context>
  <context>
    <name>installscript</name>
    <message>
      <source>Text for translation #2 </source>
      <oldcomment>some new comments here</oldcomment>
      <translation type="unfinished">Text for translation #2 </translation>
    </message>
  </context>
</TS>
